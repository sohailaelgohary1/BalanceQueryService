package com.mycompany.agi_1;
import org.asteriskjava.fastagi.*;
import org.asteriskjava.fastagi.AgiChannel;
import org.asteriskjava.fastagi.AgiException;
import org.asteriskjava.fastagi.AgiRequest;
import org.asteriskjava.fastagi.BaseAgiScript;
/**
 *
 * @author kareem
 */
//public class AGI_1 extends BaseAgiScript {
//
//@Override
//public void service (AgiRequest ar, AgiChannel ac)throws AgiException{
//    answer();
//    streamFile("hello-world");
//    hangup();
//    throw new UnsupportedOperationException("NotSupported yet");
//}
//}
//public class AGI_1 {
//
//    public static void main(String[] args) {
//        AGIChannel agi = new AGIChannel();
//
//        try {
//            String msisdn = agi.getVariable("msisdn");
//
//            // Call REST service
//            URL url = new URL("http://localhost:8080/balance-api/balance?msisdn=" + msisdn);
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            conn.setRequestMethod("GET");
//
//            if (conn.getResponseCode() == 200) {
//                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//                String response = br.readLine();
//
//                // Parse JSON response
//                JSONObject json = new JSONObject(response);
//                double balance = json.getDouble("balance");
//
//                // Convert balance to speech
//                agi.exec("SayNumber", Double.toString(balance));
//            } else {
//                agi.exec("Playback", "invalid-number");
//            }
//
//        } catch (Exception e) {
//            agi.verbose("Error in AGI script: " + e.getMessage(), 1);
//        }
//    }
//}
//
//import org.asteriskjava.fastagi.AgiChannel;
//import org.asteriskjava.fastagi.AgiException;
//import org.asteriskjava.fastagi.AgiRequest;
//import org.asteriskjava.fastagi.BaseAgiScript;

//public class AGI_1 extends BaseAgiScript {
//
//    private static final String TEST_MSISDN = "20123456789";
//    private static final double TEST_BALANCE = 150.50;
//
//    @Override
//    public void service(AgiRequest request, AgiChannel channel)
//            throws AgiException {
//        try {
//            // Answer the call
//            answer();
//
//            // Speak welcome message using TTS
//            exec("Festival", "Welcome to balance inquiry service");
//
//            // Prompt for MSISDN
//            //String msisdn = getData("silence/1", 5000, "Please enter your 10 digit phone number followed by pound", 10000 );
////            String msisdn  = getDigits("Please enter your 10 digit phone number", 
////                                    10000,  // timeout in ms
////                                    10);
//              String msisdn = getData(TEST_MSISDN, 0)
//              String msisdn = getData(TEST_MSISDN, 0, 0)
//            // Validate input
//            if (msisdn == null || msisdn.length() != 10 || !msisdn.matches("\\d+")) {
//                exec("Festival", "Invalid number entered");
//                hangup();
//                return;
//            }
//
//            // Check if test number matches
//            if (msisdn.equals(TEST_MSISDN)) {
//                exec("Festival", "Your current balance is");
//                exec("SayNumber", Double.toString(TEST_BALANCE));
//            } else {
//                exec("Festival", "Number not found in our system");
//            }
//
//            // Goodbye message
//            exec("Festival", "Thank you for using our service");
//
//        } catch (Exception e) {
//            verbose("Error in AGI script: " + e.getMessage(), 1);
//            exec("Festival", "We are experiencing technical difficulties");
//        } finally {
//            hangup();
//        }
//    }
//}
//package com.mycompany.agi_1;
//
//import org.asteriskjava.fastagi.AgiChannel;
//import org.asteriskjava.fastagi.AgiException;
//import org.asteriskjava.fastagi.AgiRequest;
//import org.asteriskjava.fastagi.BaseAgiScript;

public class AGI_1 extends BaseAgiScript {
    
    private static final String TEST_MSISDN = "20123456789";
    private static final double TEST_BALANCE = 150.50;
    
    @Override
    public void service(AgiRequest request, AgiChannel channel) 
            throws AgiException {
        try {
            // Log beginning of service
            verbose("AGI Balance Service started", 2);
            
            // Answer the call first
            answer();
            
            // Get MSISDN from dialplan variable
            String msisdn = getVariable("msisdn");
            verbose("Received MSISDN: " + (msisdn != null ? msisdn : "null"), 2);
            
            // Add fallback to get MSISDN directly if variable not set
            if (msisdn == null || msisdn.isEmpty()) {
                // Correct way to get caller ID in Asterisk-Java
                msisdn = request.getCallerIdNumber();
                verbose("Using CallerID as fallback: " + msisdn, 2);
            }
            
            // Format number by removing any country code prefix if present
            if (msisdn != null && msisdn.startsWith("+")) {
                msisdn = msisdn.substring(1);
            }
            
            // Validate input
            if (msisdn == null || !msisdn.matches("\\d+")) {
                verbose("Invalid number format: " + msisdn, 1);
                exec("Festival", "Invalid number entered");
                hangup();
                return;
            }
            
            // Ensure trailing digits match our test number if needed
            String trimmedMsisdn = msisdn;
            if (msisdn.length() > TEST_MSISDN.length()) {
                trimmedMsisdn = msisdn.substring(msisdn.length() - TEST_MSISDN.length());
                verbose("Trimmed MSISDN to: " + trimmedMsisdn, 2);
            }
            
            // Process valid number
            if (trimmedMsisdn.equals(TEST_MSISDN)) {
                verbose("MSISDN matched test number", 2);
                // Wait a moment before speaking
                exec("Wait", "1");
                exec("Festival", "Your current balance is");
                exec("SayNumber", Double.toString(TEST_BALANCE));
            } else {
                verbose("MSISDN not found: " + msisdn, 1);
                exec("Festival", "Number not found in our system");
            }
            
            // Goodbye message
            exec("Wait", "1");
            exec("Festival", "Thank you for using our service");
            
        } catch (Exception e) {
            verbose("Error in AGI script: " + e.getMessage(), 1);
            try {
                exec("Festival", "We are experiencing technical difficulties");
            } catch (AgiException ae) {
                verbose("Failed to play error message: " + ae.getMessage(), 1);
            }
        } finally {
            try {
                hangup();
            } catch (AgiException e) {
                verbose("Error hanging up: " + e.getMessage(), 1);
            }
        }
    }
}